<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

if (!isset($_SESSION['id_usuario'])) {
    header("Location: index.php");
    exit;
}

$idUsuario = $_SESSION['id_usuario'];
$idCancion = $_POST['id_cancion'] ?? null;

if ($idCancion) {
    $conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("DELETE FROM Favoritos_Canciones WHERE IdUsuario = ? AND IdCancion = ?");
    $stmt->bind_param("ii", $idUsuario, $idCancion);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}

header("Location: favoritos.php");
exit;
