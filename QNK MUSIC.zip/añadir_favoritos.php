<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    echo "Usuario no autenticado.";
    exit;
}

$idUsuario = $_SESSION['id_usuario'];

$titulo = $_POST['titulo'] ?? '';
$artista = $_POST['artista'] ?? '';
$portada = $_POST['portada'] ?? '';
$urlOriginal = $_POST['url'] ?? '';
$url = str_replace('open.spotify.com/track/', 'open.spotify.com/embed/track/', $urlOriginal);


if (empty($titulo) || empty($artista) || empty($url)) {
    http_response_code(400);
    echo "Faltan datos obligatorios.";
    exit;
}

$conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($conn->connect_error) {
    http_response_code(500);
    echo "Error de conexión a la base de datos.";
    exit;
}

// Verificar si el artista existe
$stmt = $conn->prepare("SELECT IdArtista FROM Artistas WHERE NombreArtista = ?");
$stmt->bind_param("s", $artista);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $idArtista = $row['IdArtista'];
} else {
    $stmtInsert = $conn->prepare("INSERT INTO Artistas (NombreArtista, ImagenArtista) VALUES (?, '')");
    $stmtInsert->bind_param("s", $artista);
    $stmtInsert->execute();
    $idArtista = $stmtInsert->insert_id;
    $stmtInsert->close();
}
$stmt->close();

// Verificar si la canción existe}
$stmt = $conn->prepare("SELECT IdCancion FROM Canciones WHERE Titulo = ? AND IdArtista = ?");
$stmt->bind_param("si", $titulo, $idArtista);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $idCancion = $row['IdCancion'];
} else {
    $nombreAlbum = ''; // Álbum vacío
    $stmtInsert = $conn->prepare("INSERT INTO Canciones (Titulo, NombreAlbum, IdArtista, Portada, URL) VALUES (?, ?, ?, ?, ?)");
    $stmtInsert->bind_param("ssiss", $titulo, $nombreAlbum, $idArtista, $portada, $url);
    $stmtInsert->execute();
    $idCancion = $stmtInsert->insert_id;
    $stmtInsert->close();
}


$stmt->close();

// Añadir a favoritos si no lo está
$stmt = $conn->prepare("SELECT * FROM Favoritos_Canciones WHERE IdUsuario = ? AND IdCancion = ?");
$stmt->bind_param("ii", $idUsuario, $idCancion);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $stmtInsert = $conn->prepare("INSERT INTO Favoritos_Canciones (IdUsuario, IdCancion) VALUES (?, ?)");
    $stmtInsert->bind_param("ii", $idUsuario, $idCancion);
    $stmtInsert->execute();
    $stmtInsert->close();
    echo "Canción añadida a favoritos.";
} else {
    echo "Ya está en favoritos.";
}
$stmt->close();
$conn->close();
