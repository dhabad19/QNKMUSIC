<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Inicio de Sesión</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="css/index.css" rel="stylesheet">
    <script src="js/index.js" defer></script>
    <link rel="icon" href="img/qnk.png" type="image/png">
</head>

<body>
    <div class="container">
        <section class="vh-300 bg-dark">
            <div class="container py-5 h-100">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col">
                        <div class="card shadow-2-strong" style="border-radius: 1rem;">
                            <div class="card-body p-5 text-center">
                                <img class="img" src="img/qnk.png">
                                <?php
                                include "include/CredencialesBD.php";
                                $c1 = new mysqli($dbhost, $usuario, $password);
                                if ($c1->connect_error) die("Error de conexión: " . $c1->connect_error);

                                $c1->query("CREATE DATABASE IF NOT EXISTS u968449334_reproductor");
                                $c1->query("USE u968449334_reproductor");

                                $sqlQueries = [

                                    "CREATE TABLE IF NOT EXISTS Usuarios (
                                        IdUsuario INT AUTO_INCREMENT PRIMARY KEY,
                                        Nombre VARCHAR(50) NOT NULL,
                                        Usuario VARCHAR(50) NOT NULL,
                                        Email VARCHAR(50) UNIQUE NOT NULL,
                                        Imagen VARCHAR(255),
                                        Contraseña VARCHAR(255) NOT NULL
                                    )",

                                    "CREATE TABLE IF NOT EXISTS Artistas (
                                        IdArtista INT AUTO_INCREMENT PRIMARY KEY,
                                        NombreArtista VARCHAR(100) NOT NULL,
                                        ImagenArtista VARCHAR(255)
                                    )",

                                    "CREATE TABLE IF NOT EXISTS Canciones (
                                        IdCancion INT AUTO_INCREMENT PRIMARY KEY,
                                        Titulo VARCHAR(100) NOT NULL,
                                        NombreAlbum VARCHAR(100),
                                        Portada VARCHAR(255),
                                        URL VARCHAR(255),
                                        IdArtista INT NULL,
                                        FOREIGN KEY (IdArtista) REFERENCES Artistas(IdArtista)
                                    )",

                                    "CREATE TABLE IF NOT EXISTS Playlist (
                                        IdPlaylist INT AUTO_INCREMENT PRIMARY KEY,
                                        NombrePlaylist VARCHAR(100) NOT NULL,
                                        ImagenPlaylist VARCHAR(255),
                                        IdUsuario INT NOT NULL,
                                        FOREIGN KEY (IdUsuario) REFERENCES Usuarios(IdUsuario)
                                            ON DELETE CASCADE
                                            ON UPDATE CASCADE
                                    )",

                                    "CREATE TABLE IF NOT EXISTS Favoritos_Canciones (
                                        IdUsuario INT NOT NULL,
                                        IdCancion INT NOT NULL,
                                        PRIMARY KEY (IdUsuario, IdCancion),
                                        FOREIGN KEY (IdUsuario) REFERENCES Usuarios(IdUsuario)
                                            ON DELETE CASCADE
                                            ON UPDATE CASCADE,
                                        FOREIGN KEY (IdCancion) REFERENCES Canciones(IdCancion)
                                            ON DELETE CASCADE
                                            ON UPDATE CASCADE
                                    )",

                                    "CREATE TABLE IF NOT EXISTS Playlist_Canciones (
                                        IdPlaylist INT NOT NULL,
                                        IdCancion INT NOT NULL,
                                        PRIMARY KEY (IdPlaylist, IdCancion),
                                        FOREIGN KEY (IdPlaylist) REFERENCES Playlist(IdPlaylist)
                                            ON DELETE CASCADE
                                            ON UPDATE CASCADE,
                                        FOREIGN KEY (IdCancion) REFERENCES Canciones(IdCancion)
                                            ON DELETE CASCADE
                                            ON UPDATE CASCADE
                                    )",

                                    "CREATE TABLE IF NOT EXISTS HistorialUltimaReproduccion (
                                        IdUsuario INT PRIMARY KEY,
                                        UltimoTitulo VARCHAR(100) NOT NULL,
                                        UltimoArtista VARCHAR(100) NOT NULL,
                                        UltimaPortada VARCHAR(255),
                                        UltimaURL VARCHAR(255),
                                        FechaActualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                                        FOREIGN KEY (IdUsuario) REFERENCES Usuarios(IdUsuario)
                                            ON DELETE CASCADE
                                            ON UPDATE CASCADE
                                    )",

                                    "CREATE TABLE IF NOT EXISTS Historial_Reproduccion (
                                        IdHistorial INT AUTO_INCREMENT PRIMARY KEY,
                                        IdUsuario INT NOT NULL,
                                        IdCancion INT NOT NULL,
                                        FechaReproduccion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                        FOREIGN KEY (IdUsuario) REFERENCES Usuarios(IdUsuario)
                                            ON DELETE CASCADE
                                            ON UPDATE CASCADE,
                                        FOREIGN KEY (IdCancion) REFERENCES Canciones(IdCancion)
                                            ON DELETE CASCADE
                                            ON UPDATE CASCADE
                                    )"
                                ];

                                foreach ($sqlQueries as $query) {
                                    if (!$c1->query($query)) {
                                        echo "<p>Error al crear tabla: " . $c1->error . "</p>";
                                    }
                                }

                                // Crear usuario administrador por defecto si no existe
                                $adminEmail = 'admnstradr@gmail.com';
                                $adminPassword = password_hash('1234', PASSWORD_DEFAULT);
                                $existeAdmin = $c1->query("SELECT * FROM Usuarios WHERE Email = '$adminEmail'");
                                if ($existeAdmin->num_rows === 0) {
                                    $c1->query("INSERT INTO Usuarios (Nombre, Usuario, Email, Imagen, Contraseña)
                                                VALUES ('Admin', '@admin', '$adminEmail', 'IMAGEN', '$adminPassword')");
                                }

                                $c1->close();

                                if (isset($_POST['acceder'])) {
                                    $c1 = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
                                    $u = $_POST['usuario'];
                                    $c = $_POST['contraseña'];

                                    $res = $c1->query("SELECT Contraseña FROM Usuarios WHERE Email = '$u'");
                                    $row = $res->fetch_assoc();
                                    $contra = $row['Contraseña'] ?? null;

                                    if ($contra && password_verify($c, $contra)) {
                                        $datos = $c1->query("SELECT IdUsuario, Nombre, Usuario, Email, Imagen FROM Usuarios WHERE Email = '$u'")->fetch_assoc();
                                        $_SESSION['usuario'] = $datos;
                                        $_SESSION['id_usuario'] = $datos['IdUsuario'];
                                        header('Location: inicio.php');
                                        exit;
                                    } else {
                                        echo "<p style='color: red;'>Usuario o contraseña incorrectos.</p>";
                                    }

                                    $c1->close();
                                }

                            

                                ?>



                                <form method="post" class="mt-4">
                                    <div class="form-outline mb-4 text-start">
                                        <label for="usuario" class="form-label">Correo electrónico:</label>
                                        <input type="email" id="usuario" name="usuario" class="form-control form-control-lg" required />
                                    </div>

                                    <div class="form-outline mb-4 text-start">
                                        <label for="contraseña" class="form-label">Contraseña:</label>
                                        <div class="input-group">
                                            <input type="password" id="contraseña" name="contraseña" class="form-control form-control-lg" required />
                                            <button type="button" id="MostrarContraseña" class="btn btn-outline-secondary">👁️</button>
                                        </div>
                                    </div>

                                    <button class="btn btn-primary btn-lg btn-block" name="acceder" type="submit">Acceder</button>
                                </form>

                                <form method="post" action="form_registro_usuario.php" class="mt-3">
                                    <button class="btn btn-secondary btn-lg btn-block" name="enviar" type="submit">Registrarse</button>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</body>

</html>