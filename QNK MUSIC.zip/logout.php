<?php
session_start();

// Eliminar todas las variables de sesión
session_unset();

// Destruir la sesión
session_destroy();

// Prevenir que se use el caché del navegador para volver atrás
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

// Redirigir al inicio de sesión
header("Location: index.php");
exit;
