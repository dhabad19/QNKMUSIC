<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

if (!isset($_SESSION['id_usuario'])) {
    header("Location: index.php");
    exit;
}

$idUsuario = $_SESSION['id_usuario'];
$nombre = $_POST['nombre'] ?? '';
$imagenRuta = 'img/default_playlist.png';

if (empty($nombre)) {
    die("El nombre de la playlist no puede estar vacío.");
}

if (!empty($_FILES['imagen']['name'])) {
    $directorioDestino = "img/playlists/";
    if (!is_dir($directorioDestino)) {
        mkdir($directorioDestino, 0755, true);
    }

    $nombreArchivo = basename($_FILES['imagen']['name']);
    $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
    $extensionesValidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    if (!in_array($extension, $extensionesValidas)) {
        die("Formato de imagen no permitido.");
    }

    $nombreUnico = uniqid() . "_" . $nombreArchivo;
    $rutaCompleta = $directorioDestino . $nombreUnico;

    if (move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaCompleta)) {
        $imagenRuta = $rutaCompleta;
    }
}

$conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$stmt = $conn->prepare("INSERT INTO Playlist (NombrePlaylist, ImagenPlaylist, IdUsuario) VALUES (?, ?, ?)");
$stmt->bind_param("ssi", $nombre, $imagenRuta, $idUsuario);
$stmt->execute();
$idPlaylistCreada = $stmt->insert_id;
$stmt->close();
$conn->close();

// Si hay canción pendiente en la sesión, redirigir con datos
if (isset($_SESSION['cancion_pendiente'])) {
    $cancion = $_SESSION['cancion_pendiente'];
    unset($_SESSION['cancion_pendiente']); // Limpiar la sesión

    $queryString = http_build_query([
        'add' => 1,
        'title' => $cancion['titulo'],
        'artist' => $cancion['artista'],
        'cover' => $cancion['portada'],
        'url' => $cancion['url']
    ]);

    header("Location: playlist.php?$queryString");
    exit;
}

// Si no hay canción pendiente, ir a la lista de playlists normal
header("Location: playlist.php");
exit;
