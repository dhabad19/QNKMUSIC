<?php
session_start();

include "include/CredencialesBD.php";

if (!isset($_SESSION['id_usuario'])) {
    header("Location: index.php");
    exit;
}

$idUsuario = $_SESSION['id_usuario'];

$conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener los 5 artistas más escuchados por el usuario
$sql = "
    SELECT a.NombreArtista, COUNT(*) AS Reproducciones
    FROM Historial_Reproduccion hr
    JOIN Canciones c ON hr.IdCancion = c.IdCancion
    JOIN Artistas a ON c.IdArtista = a.IdArtista
    WHERE hr.IdUsuario = ?
    GROUP BY a.NombreArtista
    ORDER BY Reproducciones DESC
    LIMIT 5
";
;

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Error al preparar la consulta: " . $conn->error);
}
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$resultado = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Artistas Favoritos - QNK Music</title>
    <link rel="stylesheet" href="css/artistas_favoritos.css">
         <link rel="icon" href="img/qnk.png" type="image/png">
</head>
<body>

<header class="header">
    <div class="logo"><a href="./inicio.php">QNK Music</a></div>
    <nav class="navbar">
        <ul>
            <li><a href="./buscar.php">Buscar</a></li>
            <li><a href="./playlist.php">Playlist</a></li>
            <li><a href="./favoritos.php">Canciones Fav.</a></li>
            <li><a href="./form_perfil.php">Perfil</a></li>
            <li><a href="./logout.php">Cerrar Sesión</a></li>
        </ul>
    </nav>
</header>

<main class="main-content">
    <h2>Tus Artistas Más Escuchados</h2>

    <?php if ($resultado->num_rows > 0): ?>
        <ul class="artist-list">
            <?php while ($row = $resultado->fetch_assoc()): ?>
                <li>
                    <a href="buscar.php?query=<?php echo urlencode($row['NombreArtista']); ?>">
                        <?php echo htmlspecialchars($row['NombreArtista']); ?>
                    </a>
                    <span class="reproducciones">(<?php echo $row['Reproducciones']; ?> reproducciones)</span>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p class="no-artists">Aún no has reproducido música suficiente para mostrar tus artistas más escuchados.</p>
    <?php endif; ?>
</main>

</body>
</html>
