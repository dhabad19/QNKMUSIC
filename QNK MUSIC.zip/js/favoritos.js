
function reproducir(url) {
    const player = document.getElementById('player-container');
    player.innerHTML = `<iframe src="${url}" width="100%" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>`;
    player.style.display = 'block';
}
