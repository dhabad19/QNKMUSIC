
    const abrirModal = document.getElementById('btn-crear-playlist');
    const cerrarModal = document.getElementById('cerrar-modal');
    const modal = document.getElementById('modal-playlist');
  
    if (abrirModal && cerrarModal && modal) {
      abrirModal.addEventListener('click', () => {
        modal.classList.remove('hidden');
      });
  
      cerrarModal.addEventListener('click', () => {
        modal.classList.add('hidden');
      });
  
      // Cierre del modal si se hace clic fuera del formulario
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.add('hidden');
        }
      });
    } else {
      console.warn('⚠️ No se encontraron los elementos del modal en el DOM.');
    }