<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

// Comprobar que haya sesión iniciada
if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.php');
    exit;
}

$idUsuario = $_SESSION['id_usuario'];

// Conectar a la base de datos
$c1 = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($c1->connect_error) {
    die("Error de conexión: " . $c1->connect_error);
}

// Buscar la última canción reproducida del usuario
$sql = "SELECT UltimoTitulo, UltimoArtista, UltimaPortada, UltimaURL 
        FROM HistorialUltimaReproduccion 
        WHERE IdUsuario = $idUsuario";

$$hayCancion = false;
$resultado = $c1->query($sql);

if ($resultado && $fila = $resultado->fetch_assoc()) {
    $titulo = $fila['UltimoTitulo'];
    $artista = $fila['UltimoArtista'];
    $portada = $fila['UltimaPortada'];
    $previewUrl = $fila['UltimaURL'];
    $hayCancion = true;
} elseif (!$resultado) {
    error_log("Error en la consulta de historial: " . $c1->error);
}

$c1->close();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>QNK Music - Inicio</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="css/inicio.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="js/inicio.js" defer></script>
    <link rel="icon" href="img/qnk.png" type="image/png">
</head>

<body>

    <header class="header">
    <div class="logo"><a href="./inicio.php" style="color: white; text-decoration: none;">QNK Music</a></div>
        <nav class="navbar">
            <ul>
                <li><a href="./buscar.php">Buscar</a></li>
                <li><a href="./form_perfil.php">Perfil</a></li>
                <li><a href="./logout.php">Cerrar Sesión</a></li>
            </ul>
        </nav>
    </header>

    <main class="main-content">

        <?php if ($hayCancion): ?>
            <section class="now-playing">
                <h2>Última canción escuchada:</h2>
                <div class="song-info">
                    <img src="<?php echo htmlspecialchars($portada); ?>" alt="Portada" class="img-album">
                    <div class="details">
                        <h3><?php echo htmlspecialchars($titulo); ?></h3>
                        <p><?php echo htmlspecialchars($artista); ?></p>
                    </div>
                </div>

                <?php
                // Extraer solo el ID de la URL
                $trackId = '';
                if (strpos($previewUrl, 'track/') !== false) {
                    $parts = explode('track/', $previewUrl);
                    if (isset($parts[1])) {
                        $trackId = strtok($parts[1], '?'); // Quitar parámetros como ?si=
                    }
                }
                ?>

                <?php if ($trackId): ?>
                    <div class="spotify-player">
                        <iframe src="https://open.spotify.com/embed/track/<?php echo htmlspecialchars($trackId); ?>" width="100%" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
                    </div>
                <?php else: ?>
                    <p>Error al cargar la canción.</p>
                <?php endif; ?>

            </section>
        <?php else: ?>
            <section class="now-playing">
                <h2>Bienvenido a QNK Music</h2>
                <p>¡Todavía no has reproducido ninguna canción!</p>
            </section>
        <?php endif; ?>

        <section class="features">
            <h2>Explorar</h2>
            <div class="feature-list">
                <div class="feature">
                    <h3><a href="./playlist.php">Playlist</a></h3>
                    <p>Gestiona tus listas de reproducción.</p>
                </div>
                <div class="feature">
                    <h3><a href="./favoritos.php">Canciones Favoritas</a></h3>
                    <p>Accede a tus canciones favoritas.</p>
                </div>
                <div class="feature">
                    <h3><a href="./artistas_favoritos.php">Artistas Favoritos</a></h3>
                    <p>Descubre más de tus artistas favoritos.</p>
                </div>
            </div>
        </section>

    </main>

    <footer class="footer">
        <p>&copy; 2025 QNK Miusik. Todos los derechos reservados.</p>
    </footer>

</body>

</html>