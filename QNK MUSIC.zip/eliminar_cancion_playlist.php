<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

// Verifica que el usuario haya iniciado sesión
if (!isset($_SESSION['id_usuario'])) {
    header("Location: index.php");
    exit;
}

$idUsuario = $_SESSION['id_usuario'];
$idPlaylist = $_POST['id_playlist'] ?? null;
$idCancion = $_POST['id_cancion'] ?? null;

if (!$idPlaylist || !$idCancion) {
    die("Faltan datos para eliminar la canción.");
}

// Conectar a la base de datos
$conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// ✅ Verificar que la playlist pertenece al usuario
$stmtCheck = $conn->prepare("SELECT IdPlaylist FROM Playlist WHERE IdPlaylist = ? AND IdUsuario = ?");
$stmtCheck->bind_param("ii", $idPlaylist, $idUsuario);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();

if ($resultCheck->num_rows === 0) {
    die("No tienes permiso para modificar esta playlist.");
}
$stmtCheck->close();

// Eliminar la canción de la playlist
$stmt = $conn->prepare("DELETE FROM Playlist_Canciones WHERE IdPlaylist = ? AND IdCancion = ?");
$stmt->bind_param("ii", $idPlaylist, $idCancion);
$stmt->execute();
$stmt->close();

$conn->close();

// Redirigir de nuevo a la playlist
header("Location: ver_playlist.php?id=$idPlaylist");
exit;
