<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

// Comprobar que haya sesión activa
if (!isset($_SESSION['id_usuario'])) {
    header("Location: index.php");
    exit;
}

$idUsuario = $_SESSION['id_usuario'];

// Recoger datos del formulario
$playlistId = $_POST['playlist_id'] ?? null;
$titulo = $_POST['title'] ?? '';
$artista = $_POST['artist'] ?? '';
$portada = $_POST['cover'] ?? 'img/default_cover.png';
$url = $_POST['url'] ?? '';
$search = $_POST['search'] ?? '';




// Guardar búsqueda actual para redirección
if (!empty($search)) {
    $_SESSION['busqueda_actual'] = $search;
}

if (!$playlistId || !$titulo || !$artista || !$url) {
    die("Faltan datos para añadir la canción.");
}

// Conectar a la BD
$conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// 1. Verificar si el artista ya existe
$stmtArtista = $conn->prepare("SELECT IdArtista FROM Artistas WHERE NombreArtista = ?");
$stmtArtista->bind_param("s", $artista);
$stmtArtista->execute();
$resultArtista = $stmtArtista->get_result();

if ($row = $resultArtista->fetch_assoc()) {
    $idArtista = $row['IdArtista'];
} else {
    // Insertar artista
    $stmtInsertArtista = $conn->prepare("INSERT INTO Artistas (NombreArtista, ImagenArtista) VALUES (?, '')");
    $stmtInsertArtista->bind_param("s", $artista);
    $stmtInsertArtista->execute();
    $idArtista = $stmtInsertArtista->insert_id;
    $stmtInsertArtista->close();
}
$stmtArtista->close();

// 2. Verificar si la canción ya existe
$stmtCancion = $conn->prepare("SELECT IdCancion FROM Canciones WHERE Titulo = ? AND IdArtista = ?");
$stmtCancion->bind_param("si", $titulo, $idArtista);
$stmtCancion->execute();
$resultCancion = $stmtCancion->get_result();

if ($row = $resultCancion->fetch_assoc()) {
    $idCancion = $row['IdCancion'];
} else {
    // Insertar canción con portada
    $stmtInsertCancion = $conn->prepare("INSERT INTO Canciones (Titulo, NombreAlbum, Portada, IdArtista) VALUES (?, ?, ?, ?)");
    $nombreAlbum = '';
    $stmtInsertCancion->bind_param("sssi", $titulo, $nombreAlbum, $portada, $idArtista);
    $stmtInsertCancion->execute();
    $idCancion = $stmtInsertCancion->insert_id;
    $stmtInsertCancion->close();
}
$stmtCancion->close();

// 3. Insertar en Playlist_Canciones si no existe
$stmtCheck = $conn->prepare("SELECT * FROM Playlist_Canciones WHERE IdPlaylist = ? AND IdCancion = ?");
$stmtCheck->bind_param("ii", $playlistId, $idCancion);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();

if ($resultCheck->num_rows === 0) {
    $stmtInsert = $conn->prepare("INSERT INTO Playlist_Canciones (IdPlaylist, IdCancion) VALUES (?, ?)");
    $stmtInsert->bind_param("ii", $playlistId, $idCancion);
    $stmtInsert->execute();
    $stmtInsert->close();
}

$stmtCheck->close();
$conn->close();

// Limpiar sesión y redirigir
$query = $_SESSION['busqueda_actual'] ?? '';
unset($_SESSION['busqueda_actual'], $_SESSION['cancion_pendiente']);
header("Location: buscar.php?query=" . urlencode($search));


exit;
?>
