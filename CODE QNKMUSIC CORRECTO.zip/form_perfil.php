<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

// Conectar
$c1 = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($c1->connect_error) {
    die("Error de conexión: " . $c1->connect_error);
}

// Comprobar sesión
if (!isset($_SESSION['id_usuario'])) {
    die("⚠️ Error: No hay sesión iniciada.");
}
$idUsuario = $_SESSION['id_usuario'];

if (isset($_POST['eliminar_cuenta'])) {
    // Eliminar imagen si existe
    if (!empty($usuario['Imagen']) && file_exists($usuario['Imagen'])) {
        unlink($usuario['Imagen']); // 🧹 Borrar imagen del servidor
    }

    // Eliminar el usuario de la base de datos
    $sql = "DELETE FROM Usuarios WHERE IdUsuario = $idUsuario";

    if ($c1->query($sql)) {
        session_destroy(); // 🔒 Cerramos la sesión
        header("Location: index.php"); // 🔄 Redirigir al login
        exit;
    } else {
        echo "<script>alert('❌ No se pudo eliminar la cuenta');</script>";
    }
}

// Primero recuperamos los datos del usuario
$resultado = $c1->query("SELECT * FROM Usuarios WHERE IdUsuario = $idUsuario");
$usuario = $resultado->fetch_assoc();

// Solo después los usamos en el bloque de edición
if (isset($_POST['guardar_cambios'])) {
    $nuevoNombre = $_POST['nombre'];
    $nuevoUsuario = $_POST['usuario'];
    $nuevoEmail = $_POST['email'];
    $nuevaContraseña = $_POST['nueva_contraseña'];
    $nuevaImagen = $usuario['Imagen']; // Ya está definido porque está antes

    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == 0) {
        $permitidos = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        $maxSize = 2 * 1024 * 1024;

        if (in_array($_FILES['imagen']['type'], $permitidos) && $_FILES['imagen']['size'] <= $maxSize) {
            $extension = pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION);
            $nombreUnico = uniqid('img_', true) . '.' . $extension;
            $rutaDestino = "img/usuarios/$nombreUnico";

            if (!is_dir("img/usuarios")) {
                mkdir("img/usuarios", 0755, true);
            }

            if (move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino)) {
                $nuevaImagen = $rutaDestino;
            } else {
                echo "<script>alert('❌ Error al mover la imagen');</script>";
            }
        } else {
            echo "<script>alert('⚠️ Imagen no válida: solo se permiten JPG, PNG y máximo 2MB');</script>";
        }
    }

    if (!empty($nuevaContraseña)) {
        $hash = password_hash($nuevaContraseña, PASSWORD_DEFAULT);
        $sql = "UPDATE Usuarios SET Nombre='$nuevoNombre', Usuario='$nuevoUsuario', Email='$nuevoEmail', Imagen='$nuevaImagen', Contraseña='$hash' WHERE IdUsuario=$idUsuario";
    } else {
        $sql = "UPDATE Usuarios SET Nombre='$nuevoNombre', Usuario='$nuevoUsuario', Email='$nuevoEmail', Imagen='$nuevaImagen' WHERE IdUsuario=$idUsuario";
    }

    if ($c1->query($sql)) {
        $_SESSION['nombre_usuario'] = $nuevoNombre;
        header("Location: form_perfil.php");
        exit;
    } else {
        echo "<script>alert('Error al guardar los cambios');</script>";
    }
}

// Detectar modo edición
$modo_edicion = isset($_POST['editar_perfil']) || isset($_POST['guardar_cambios']);

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Cuenta</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="css/perfil.css" rel="stylesheet" type="text/css">
    <script src="js/registro.js"></script>
    <script src="js/buscar.js" defer></script>
    <link rel="icon" href="img/qnk.png" type="image/png">
</head>

<body>
    <header class="header">
        <div class="logo">
    <div class="logo"><a href="./inicio.php" style="color: white; text-decoration: none;">QNK Music</a></div>
        </div>
        <nav class="navbar">
            <ul>
                <li><a href="./buscar.php">Buscar</a></li>
                <li><a href="./playlist.php">Playlist</a></li>
                <li><a href="./artistas_favoritos.php">Artistas Favoritos</a></li>
                <li><a href="./favoritos.php">Canciones Favoritas</a></li>
                <li><a href="./logout.php">Cerrar Sesión</a></li>
            </ul>
        </nav>
    </header>

    <main class="main-content">
        <section class="features">
            <h2 class="text-center">Mi Perfil</h2>
            <div class="profile-info text-center">
                <?php if ($modo_edicion): ?>
                    <form method="post" action="form_perfil.php" class="p-3" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>Nombre:</label>
                            <input type="text" name="nombre" class="form-control" value="<?php echo htmlspecialchars($usuario['Nombre']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Usuario:</label>
                            <input type="text" name="usuario" class="form-control" value="<?php echo htmlspecialchars($usuario['Usuario']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Email:</label>
                            <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($usuario['Email']); ?>" required>
                        </div>
                        <div class="form-group text-center">
                            <label>Imagen actual:</label><br>
                            <?php if (!empty($usuario['Imagen'])): ?>
                                <img src="<?php echo htmlspecialchars($usuario['Imagen']); ?>" alt="Imagen de perfil" width="150" height="150" style="border-radius: 50%; object-fit: cover;">
                            <?php else: ?>
                                <p>No hay imagen</p>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label>Subir nueva imagen:</label>
                            <input type="file" name="imagen" class="form-control">
                        </div>

                        <div class="form-group">
                            <label>Contraseña nueva (opcional):</label>
                            <input type="password" name="nueva_contraseña" class="form-control">
                        </div>
                        <button type="submit" name="guardar_cambios" class="btn btn-success mt-3">Guardar cambios</button>
                    </form>
                <?php else: ?>
                    <h3><?php echo htmlspecialchars($usuario['Nombre']); ?></h3>
                    <?php if (!empty($usuario['Imagen'])): ?>
                        <img src="<?php echo htmlspecialchars($usuario['Imagen']); ?>" width="100" style="border-radius: 50%; object-fit: cover;">
                    <?php else: ?>
                        <p><strong>Imagen:</strong> No hay imagen</p>
                    <?php endif; ?>
                    <p><strong>Usuario:</strong> <?php echo htmlspecialchars($usuario['Usuario']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($usuario['Email']); ?></p>
                    <p><strong>Contraseña:</strong> ********</p>
                    <form method="post" action="form_perfil.php">
                        <button type="submit" name="editar_perfil" class="btn btn-primary">Editar Perfil</button>
                    </form>
                <?php endif; ?>
            </div>

            <div class="profile-actions text-center">
                <br>
                <form method="post" action="form_perfil.php" onsubmit="return confirm('¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.');">
                    <button type="submit" name="eliminar_cuenta" class="btn btn-danger">Eliminar Cuenta</button>
                </form>
            </div>
        </section>
    </main>

    <footer class="footer">
        <p>&copy; 2025 QNK Miusik. Todos los derechos reservados.</p>
    </footer>
</body>

</html>