<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");


include "include/CredencialesBD.php";

$busquedaOriginal = $_GET['query'] ?? '';



if (isset($_GET['add']) && $_GET['add'] == 1) {
    $_SESSION['cancion_pendiente'] = [
        'titulo' => $_GET['title'] ?? '',
        'artista' => $_GET['artist'] ?? '',
        'portada' => $_GET['cover'] ?? '',
        'url' => $_GET['url'] ?? ''
    ];
    $_SESSION['busqueda_original'] = $_GET['search'] ?? '';
}



if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.php');
    exit;
}

$idUsuario = $_SESSION['id_usuario'];

$titulo = $_GET['title'] ?? '';
$artista = $_GET['artist'] ?? '';
$portada = $_GET['cover'] ?? '';
$url = $_GET['url'] ?? '';
$modoAñadir = isset($_GET['add']) && $_GET['add'] == 1;

$conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$playlists = $conn->query("SELECT IdPlaylist, NombrePlaylist, ImagenPlaylist FROM Playlist WHERE IdUsuario = $idUsuario");
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Mis Playlists - QNK Music</title>
    <link rel="stylesheet" href="css/playlist.css">
        <link rel="icon" href="img/qnk.png" type="image/png">
    <script src="js/playlist.js" defer></script>
</head>

<body>

<header class="header">
    <div class="logo"><a href="./inicio.php">QNK Music</a></div>
    <nav class="navbar">
        <ul>
            <li><a href="buscar.php">Buscar</a></li>
            <li><a href="./favoritos.php">Canciones Fav</a></li>
            <a href="./artistas_favoritos.php">Artistas Fav</a></li>
            <li><a href="form_perfil.php">Perfil</a></li>
            <li><a href="./logout.php">Cerrar Sesión</a></li><li>
        </ul>
    </nav>
</header>

<main class="main-content">
    <h2>Tus Playlists</h2>

    <div class="create-playlist-container">
        <button id="btn-crear-playlist">➕ Crear nueva playlist</button>
    </div>

    <div id="modal-playlist" class="modal-playlist hidden">
        <form method="POST" action="crear_playlist.php" class="modal-form" enctype="multipart/form-data">
            <h3>Crear nueva playlist</h3>
            <input type="text" name="nombre" placeholder="Nombre de la playlist" required>
            <input type="file" name="imagen" accept="image/*">
            <div class="modal-buttons">
                <button type="submit">Crear</button>
                <button type="button" id="cerrar-modal">Cancelar</button>
            </div>
        </form>
    </div>

    <?php if ($modoAñadir && $titulo): ?>
        <section class="selected-song">
            <h4>Vas a añadir esta canción:</h4>
            <div class="song-preview">
                <img src="<?php echo htmlspecialchars($portada); ?>" alt="portada">
                <div class="song-info">
                    <strong><?php echo htmlspecialchars($titulo); ?></strong>
                    <span><?php echo htmlspecialchars($artista); ?></span>
                </div>
            </div>
            <p>Selecciona una playlist:</p>
        </section>
    <?php endif; ?>

    <div class="playlist-list">
        <?php while ($playlist = $playlists->fetch_assoc()): ?>
            <?php
            $imagen = htmlspecialchars($playlist['ImagenPlaylist'] ?? 'img/default_playlist.png');
            $esPorDefecto = $imagen === 'img/default_playlist.png';
            ?>
            <div class="playlist-card">
                <?php if ($modoAñadir && $titulo): ?>
                    <form method="POST" action="añadir_playlist.php">
                        <input type="hidden" name="playlist_id" value="<?= $playlist['IdPlaylist'] ?>">
                        <input type="hidden" name="title" value="<?= htmlspecialchars($titulo) ?>">
                        <input type="hidden" name="artist" value="<?= htmlspecialchars($artista) ?>">
                        <input type="hidden" name="cover" value="<?= htmlspecialchars($portada) ?>">
                        <input type="hidden" name="url" value="<?= htmlspecialchars($url) ?>">
                        <input type="hidden" name="search" value="<?= htmlspecialchars($_GET['query'] ?? '') ?>">


                        <button type="submit">
                            <?php if (!$esPorDefecto): ?>
                                <img src="<?= $imagen ?>" alt="playlist">
                            <?php endif; ?>
                            <p><?= htmlspecialchars($playlist['NombrePlaylist']) ?></p>
                        </button>
                    </form>
                <?php else: ?>
                    <a href="ver_playlist.php?id=<?= $playlist['IdPlaylist'] ?>" class="playlist-link">
                        <?php if (!$esPorDefecto): ?>
                            <img src="<?= $imagen ?>" alt="playlist">
                        <?php endif; ?>
                        <p><?= htmlspecialchars($playlist['NombrePlaylist']) ?></p>
                    </a>
                <?php endif; ?>

                <form method="POST" action="eliminar_playlist.php" class="form-eliminar" onsubmit="return confirm('¿Seguro que quieres eliminar esta playlist?');">
                    <input type="hidden" name="playlist_id" value="<?= $playlist['IdPlaylist'] ?>">
                    <input type="hidden" name="imagen" value="<?= $imagen ?>">
                    <button type="submit" class="btn-eliminar">🗑️</button>
                </form>
            </div>
        <?php endwhile; ?>
    </div>

</main>

</body>
</html>