async function obtenerToken() {
    const clientId = "0e3efbae8bae45fe9f2597006718f2cb";
    const clientSecret = "e37645b702144757af476d5c66f04ca4";

    const respuesta = await fetch("https://accounts.spotify.com/api/token", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Authorization: "Basic " + btoa(clientId + ":" + clientSecret)
        },
        body: "grant_type=client_credentials"
    });

    const datos = await respuesta.json();

    if (datos.access_token) {
        console.log("✅ Token obtenido:", datos.access_token);
    } else {
        console.error("❌ Error al obtener token:", datos);
    }
}

// Ejecutar la función
obtenerToken();
