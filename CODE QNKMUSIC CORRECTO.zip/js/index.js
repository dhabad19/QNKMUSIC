    const contraseña = document.getElementById("contraseña");
    const botonMostrar = document.getElementById("MostrarContraseña");

    if (contraseña && botonMostrar) {
        botonMostrar.addEventListener("click", function (event) {
            event.preventDefault(); // Cancelamos evento submit

            if (contraseña.type === "password") {
                contraseña.type = "text";
                botonMostrar.textContent = "🙈";
            } else {
                contraseña.type = "password";
                botonMostrar.textContent = "👁️";
            }
        });
    }