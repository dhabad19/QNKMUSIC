
let accessToken = "";
let offset = 0;
const limit = 10;
let currentQuery = "";
let isFetching = false;
let observer = null;

(async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const query = urlParams.get('query');

    if (query) {
        const input = document.getElementById("search-input");
        if (input) {
            input.value = query;
            currentQuery = query;
            offset = 0;
            await searchSpotify(query, false);
        } else {
            console.error("No se encontró el input con ID 'search-input'");
        }
    }
})();

async function getAccessToken() {
    const response = await fetch("include/token_spotify.php");
    const data = await response.json();
    return data.access_token;
}

async function searchSpotify(query, append = false) {
    if (!accessToken) accessToken = await getAccessToken();
    isFetching = true;

    const response = await fetch(`https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=${limit}&offset=${offset}`, {
        headers: {
            "Authorization": `Bearer ${accessToken}`
        }
    });

    const data = await response.json();
    displayResults(data, append);
    isFetching = false;
}

function displayResults(results, append = false) {
    const container = document.getElementById("search-results");
    if (!append) container.innerHTML = "";

    if (results.tracks && results.tracks.items.length > 0) {
        results.tracks.items.forEach(track => {
            const item = document.createElement("div");
            item.classList.add("result-item");

            const trackId = track.id;
            const title = track.name;
            const artist = track.artists.map(artist => artist.name).join(", ");
            const cover = track.album.images[0]?.url || "img/default_cover.png";
            const previewUrl = track.external_urls.spotify;

            item.innerHTML = `
                <img src="${cover}" alt="${title}" class="album-cover">
                <div class="result-details">
                    <strong>${title}</strong>
                    <span>${artist}</span>
                </div>
                <div class="result-actions">
                    <button class="btn-fav" title="Favorito" data-track='${JSON.stringify({ title, artist, cover, url: previewUrl })}'>❤️</button>
                    <a href="playlist.php?add=1&title=${encodeURIComponent(title)}&artist=${encodeURIComponent(artist)}&cover=${encodeURIComponent(cover)}&url=${encodeURIComponent(previewUrl)}&query=${encodeURIComponent(currentQuery)}" class="btn-playlist" title="Añadir a Playlist">➕</a>
                </div>
            `;

            item.querySelector('.btn-fav').addEventListener('click', (e) => {
                e.stopPropagation();
                const trackData = JSON.parse(e.currentTarget.dataset.track);

                fetch('añadir_favoritos.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: `titulo=${encodeURIComponent(trackData.title)}&artista=${encodeURIComponent(trackData.artist)}&portada=${encodeURIComponent(trackData.cover)}&url=${encodeURIComponent(trackData.url)}`
                })
                .then(response => response.text())
                .then(data => {
                    alert(data);
                });
            });

            item.addEventListener('click', (e) => {
                if (!e.target.classList.contains('btn-fav') && !e.target.classList.contains('btn-playlist')) {
                    loadSpotifyPlayer(trackId);

                    fetch('guardar_historial.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: `titulo=${encodeURIComponent(title)}&artista=${encodeURIComponent(artist)}&portada=${encodeURIComponent(cover)}&preview_url=${encodeURIComponent(previewUrl)}`
                    });
                }
            });

            container.appendChild(item);
        });

        setupObserver();
    } else if (!append) {
        container.innerHTML = "<p>No se encontraron resultados.</p>";
    }
}

function loadSpotifyPlayer(trackId) {
    const playerContainer = document.getElementById('player-container');
    playerContainer.innerHTML = `
        <iframe src="https://open.spotify.com/embed/track/${trackId}" width="100%" height="80" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
    `;
    playerContainer.style.display = 'block';
}

function setupObserver() {
    if (observer) observer.disconnect();

    const container = document.getElementById('search-results');
    const lastItem = container.lastElementChild;

    if (lastItem) {
        observer = new IntersectionObserver(async (entries) => {
            if (entries[0].isIntersecting && !isFetching && currentQuery.length > 2) {
                offset += limit;
                await searchSpotify(currentQuery, true);
            }
        });

        observer.observe(lastItem);
    }
}

document.getElementById("search-input").addEventListener("input", async (event) => {
    const query = event.target.value.trim();
    currentQuery = query;
    offset = 0;

    if (query.length > 2) {
        await searchSpotify(query, false);
    } else {
        document.getElementById("search-results").innerHTML = "";
        document.getElementById("player-container").style.display = 'none';
    }
});
