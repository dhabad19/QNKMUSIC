    document.getElementById('btnMostrar1').addEventListener('click', function () {
        const input = document.getElementById('contraseña');
        input.type = input.type === 'password' ? 'text' : 'password';
        this.textContent = input.type === 'password' ? '👁️' : '🙈';
    });

    document.getElementById('btnMostrar2').addEventListener('click', function () {
        const input = document.getElementById('contraseña2');
        input.type = input.type === 'password' ? 'text' : 'password';
        this.textContent = input.type === 'password' ? '👁️' : '🙈';
    });
