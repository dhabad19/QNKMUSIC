document.addEventListener('DOMContentLoaded', () => {
  let formToSubmit = null;

  // Detectar todos los formularios de eliminación
  document.querySelectorAll('.form-eliminar').forEach(form => {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      formToSubmit = form;
      document.getElementById('modal-confirm').classList.remove('hidden');
    });
  });

  // Cancelar eliminación
  document.getElementById('cancel-delete').addEventListener('click', () => {
    formToSubmit = null;
    document.getElementById('modal-confirm').classList.add('hidden');
  });

  // Confirmar eliminación
  document.getElementById('confirm-delete').addEventListener('click', () => {
    if (formToSubmit) {
      formToSubmit.submit();
    }
  });
});
