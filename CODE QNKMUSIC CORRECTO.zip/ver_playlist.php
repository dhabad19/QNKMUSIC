<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

// Verifica que el usuario haya iniciado sesión
if (!isset($_SESSION['id_usuario'])) {
    header("Location: index.php");
    exit;
}

$idUsuario = $_SESSION['id_usuario'];
$idPlaylist = $_GET['id'] ?? null;

if (!$idPlaylist) {
    echo "ID de playlist no proporcionado.";
    exit;
}

// Conectar a la base de datos
$conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener información de la playlist
$stmt = $conn->prepare("SELECT NombrePlaylist, ImagenPlaylist FROM Playlist WHERE IdPlaylist = ? AND IdUsuario = ?");
$stmt->bind_param("ii", $idPlaylist, $idUsuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Playlist no encontrada o no pertenece a este usuario.";
    exit;
}

$playlistInfo = $result->fetch_assoc();
$stmt->close();

// Obtener canciones asociadas (sin c.URL)
$sql = "SELECT c.IdCancion, c.Titulo, c.Portada, a.NombreArtista, c.NombreAlbum
        FROM Canciones c
        JOIN Playlist_Canciones pc ON c.IdCancion = pc.IdCancion
        LEFT JOIN Artistas a ON c.IdArtista = a.IdArtista
        WHERE pc.IdPlaylist = ?";



$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Error al preparar la consulta: " . $conn->error);
}
$stmt->bind_param("i", $idPlaylist);
$stmt->execute();
$canciones = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($playlistInfo['NombrePlaylist']); ?> - QNK Music</title>
    <link rel="stylesheet" href="css/ver_playlist.css">
    <link rel="icon" href="img/qnk.png" type="image/png">
    <script src="js/ver_playlist.js" defer></script>
</head>
<body>

<header class="header">
    <div class="logo"><a href="./inicio.php">QNK Music</a></div>
    <nav class="navbar">
        <ul>
            <li><a href="./buscar.php">Buscar</a></li>
            <li><a href="./form_perfil.php">Perfil</a></li>
            <li><a href="./index.php">Cerrar Sesión</a></li>
        </ul>
    </nav>
</header>

<main class="main-content">
    <section class="playlist-header">
        <?php if ($playlistInfo['ImagenPlaylist'] !== 'img/default_playlist.png'): ?>
            <img src="<?php echo htmlspecialchars($playlistInfo['ImagenPlaylist']); ?>" alt="Portada Playlist">
        <?php endif; ?>
        <h2><?php echo htmlspecialchars($playlistInfo['NombrePlaylist']); ?></h2>
    </section>

    <?php if ($canciones->num_rows > 0): ?>
        <div class="results-container">
            <?php while ($cancion = $canciones->fetch_assoc()): ?>
                <div class="result-item">
                    <img src="<?php echo htmlspecialchars($cancion['Portada'] ?? 'img/default_cover.png'); ?>" alt="cover" class="album-cover">
                    <div class="result-details">
                        <strong><?php echo htmlspecialchars($cancion['Titulo']); ?></strong>
                        <span><?php echo htmlspecialchars($cancion['NombreArtista'] ?? 'Artista desconocido'); ?></span>
                    </div>
                    <form method="POST" action="eliminar_cancion_playlist.php" onsubmit="return confirm('¿Eliminar esta canción de la playlist?');">
                        <input type="hidden" name="id_playlist" value="<?php echo $idPlaylist; ?>">
                        <input type="hidden" name="id_cancion" value="<?php echo $cancion['IdCancion']; ?>">
                        <button type="submit" class="btn-eliminar-cancion">🗑️</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p class="no-songs">Esta playlist no contiene canciones todavía.</p>
    <?php endif; ?>
</main>

</body>
</html>
