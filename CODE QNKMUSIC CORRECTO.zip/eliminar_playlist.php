<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

if (!isset($_SESSION['id_usuario']) || !isset($_POST['playlist_id'])) {
    header("Location: playlist.php");
    exit;
}

$idUsuario = $_SESSION['id_usuario'];
$idPlaylist = intval($_POST['playlist_id']);

// Conexión
$conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// 1. Obtener ruta de la imagen de la playlist
$sql = "SELECT ImagenPlaylist FROM Playlist WHERE IdPlaylist = $idPlaylist AND IdUsuario = $idUsuario";
$res = $conn->query($sql);

if ($res && $row = $res->fetch_assoc()) {
    $rutaImagen = $row['ImagenPlaylist'];

    // 2. Eliminar la imagen solo si no es la imagen por defecto
    if ($rutaImagen !== 'img/default_playlist.png' && file_exists($rutaImagen)) {
        unlink($rutaImagen); // Elimina archivo físico
    }

    // 3. Eliminar canciones asociadas y la playlist
    $conn->query("DELETE FROM Playlist_Canciones WHERE IdPlaylist = $idPlaylist");
    $conn->query("DELETE FROM Playlist WHERE IdPlaylist = $idPlaylist AND IdUsuario = $idUsuario");
}

$conn->close();
header("Location: playlist.php");
exit;
