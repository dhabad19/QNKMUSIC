<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="css/registro.css" rel="stylesheet" type="text/css">
    <script src="js/registro.js" defer></script>
    <script src="js/buscar.js" defer></script>
    <link rel="icon" href="img/qnk.png" type="image/png">
</head>

<body>
    <div class="container">
        <section class="vh-300 bg-dark">
            <div class="container py-5 h-100">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <div class="card shadow-2-strong" style="border-radius: 1rem;">
                            <div class="card-body p-5 text-center">
                                <h1 class="mb-5">Registro</h1>
                                <form ACTION="registro_usuario.php" method="post" class="ms-2">
                                    <div class="form-outline mb-4 text-start">
                                        <label for="nombre" class="col-form-label">Nombre y Apellido:</label>
                                        <input type="text" id="nombre" name="nombre" class="form-control form-control-lg" required tittle="Introduce tu nombre" />
                                    </div>

                                    <div class="form-outline mb-4 text-start">
                                        <label for="usuario" class="col-form-label">Nombre Visible:</label>
                                        <input type="text" id="usuario" name="usuario" class="form-control form-control-lg" required tittle="Introduce tu nombre de usuario" placeholder="@Diego" />
                                    </div>

                                    <div class="form-outline mb-4 text-start">
                                        <label for="mail" class="col-form-label">Correo:</label>
                                        <input type="email" id="mail" name="mail" class="form-control form-control-lg" required />
                                    </div>

                                    <div class="form-outline mb-4 text-start">
                                        <label for="contraseña" class="col-form-label">Contraseña:</label>
                                        <div class="input-group">
                                            <input type="password" id="contraseña" name="contraseña" class="form-control form-control-lg" placeholder="**************" required />
                                            <button type="button" id="btnMostrar1" class="btn btn-outline-secondary">👁️</button>
                                        </div>
                                    </div>

                                    <div class="form-outline mb-4 text-start">
                                        <label for="contraseña2" class="col-form-label">Repetir Contraseña:</label>
                                        <div class="input-group">
                                            <input type="password" id="contraseña2" name="contraseña2" class="form-control form-control-lg" required />
                                            <button type="button" id="btnMostrar2" class="btn btn-outline-secondary">👁️</button>
                                        </div>
                                    </div>


                            </div>

                            <button class="btn btn-primary btn-lg btn-block" id="btnRegistrar" name="enviar" type="submit">Registrarse</button>
                            </form>
                            <p>
                            <form method="post" action="index.php">
                                <button class="btn btn-primary btn-lg btn-block" id='btnVolver' name="volver" type="submit">Volver a Inicio</button>
                            </form>
                            <br>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
    </div>
</body>

</html>