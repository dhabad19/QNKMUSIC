<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.php');
    exit;
}

$idUsuario = $_SESSION['id_usuario'];

if (!isset($_GET['id'])) {
    echo "ID de playlist no proporcionado.";
    exit;
}

$idPlaylist = intval($_GET['id']);

// Conexión a la BD
$c1 = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($c1->connect_error) {
    die("Error de conexión: " . $c1->connect_error);
}

// Obtener nombre e imagen de la playlist
$datos = $c1->query("SELECT NombrePlaylist, ImagenPlaylist FROM Playlist WHERE IdPlaylist = $idPlaylist AND IdUsuario = $idUsuario");
if ($datos->num_rows === 0) {
    echo "Playlist no encontrada o no pertenece al usuario.";
    exit;
}
$playlist = $datos->fetch_assoc();

// Obtener canciones de la playlist
$sql = "SELECT c.Titulo, c.NombreAlbum, a.NombreArtista
        FROM Playlist_Canciones pc
        JOIN Canciones c ON pc.IdCancion = c.IdCancion
        LEFT JOIN Artistas a ON c.IdArtista = a.IdArtista
        WHERE pc.IdPlaylist = $idPlaylist";

$canciones = $c1->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($playlist['NombrePlaylist']); ?> - Playlist</title>
    <link rel="stylesheet" href="css/playlist.css">
    <link rel="icon" href="img/qnk.png" type="image/png">
</head>
<body>

<header class="header">
    <div class="logo"><a href="./inicio.php">QNK Music</a></div>
    <nav class="navbar">
        <ul>
            <li><a href="./buscar.php">Buscar</a></li>
            <li><a href="./playlist.php">Playlist</a></li>
            <li><a href="./form_perfil.php">Perfil</a></li>
            <li><a href="./logout.php">Cerrar Sesión</a></li>
        </ul>
    </nav>
</header>

<main class="main-content">
    <div class="playlist-header">
        <img src="<?php echo htmlspecialchars($playlist['ImagenPlaylist'] ?? 'img/default_cover.png'); ?>" alt="Portada">
        <h2><?php echo htmlspecialchars($playlist['NombrePlaylist']); ?></h2>
    </div>

    <div class="songs-list">
        <?php if ($canciones->num_rows > 0): ?>
            <ul>
                <?php while ($cancion = $canciones->fetch_assoc()): ?>
                    <li>
                        <strong><?php echo htmlspecialchars($cancion['Titulo']); ?></strong><br>
                        <small><?php echo htmlspecialchars($cancion['NombreArtista'] ?? 'Desconocido'); ?> | <?php echo htmlspecialchars($cancion['NombreAlbum'] ?? ''); ?></small>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>Esta playlist no tiene canciones aún.</p>
        <?php endif; ?>
    </div>
</main>

</body>
</html>
