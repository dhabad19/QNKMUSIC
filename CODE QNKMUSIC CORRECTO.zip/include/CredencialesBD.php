<?php
$dbhost = "srv1425.hstgr.io"; // Este es el host que te da Hostinger para MySQL
$usuario = "u968449334_user"; // Este es tu usuario creado en Hostinger
$password = "l5oS0fkj&0?rL";   // Tu contraseña real de MySQL

$correo = "admnstradr@gmail.com"; // Datos del correo (si los usas)
$pswCorreo = "@dmin1234";
?>
