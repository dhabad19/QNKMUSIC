<?php
header('Content-Type: application/json');

$client_id = "0e3efbae8bae45fe9f2597006718f2cb";
$client_secret = "e37645b702144757af476d5c66f04ca4";

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://accounts.spotify.com/api/token");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers = [
    "Authorization: Basic " . base64_encode("$client_id:$client_secret"),
    "Content-Type: application/x-www-form-urlencoded"
];

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo json_encode(["error" => "Error al obtener token"]);
} else {
    echo $response;
}

curl_close($ch);
?>
