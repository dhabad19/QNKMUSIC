<?php
date_default_timezone_set('Europe/Madrid');
include "include/CredencialesBD.php";

$c1 = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($c1->connect_error) {
    die("Error de conexión a la base de datos: " . $c1->connect_error);
}

$mail = isset($_POST['mail']) ? $c1->real_escape_string($_POST['mail']) : '';
$nombre = isset($_POST['nombre']) ? $c1->real_escape_string($_POST['nombre']) : '';
$user = isset($_POST['usuario']) ? $c1->real_escape_string($_POST['usuario']) : '';
$contraseña = isset($_POST['contraseña']) ? $_POST['contraseña'] : '';

$hash = password_hash($contraseña, PASSWORD_DEFAULT);

$existe = $c1->query("SELECT IdUsuario FROM Usuarios WHERE Email = '$mail'");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro Usuario</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="css/registro.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="container">
    <section class="vh-300 bg-dark">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="card shadow-2-strong" style="border-radius: 1rem;">
                        <div class="card-body p-5 text-center">
                            <?php if ($existe && $existe->num_rows > 0): ?>
                                <h1 class="mb-5">No se ha podido registrar</h1>
                                <p style="color: red;">El correo ya está registrado en nuestra base de datos</p>
                            <?php else:
                                $insert = $c1->query("INSERT INTO Usuarios VALUES (DEFAULT, '$nombre', '$user', '$mail', 'NO IMAGE', '$hash')");
                                if ($insert): ?>
                                    <h1 class="mb-5">Usuario registrado</h1>
                                <?php else: ?>
                                    <h1 class="mb-5">Error al registrar</h1>
                                    <p style="color: red;"><?php echo $c1->error; ?></p>
                                <?php endif; ?>
                            <?php endif; ?>
                            <form method="post" action="index.php">
                                <button class="btn btn-primary btn-lg btn-block" name="env" type="submit">Volver a Inicio</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
</body>
</html>

<?php
$c1->close();
?>
