<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (isset($_GET['query'])) {
    $_SESSION['busqueda_actual'] = $_GET['query'];
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <title>Buscar Canciones - QNK Music</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/buscar.css">
  <script src="js/buscar.js" defer></script>
  <link rel="icon" href="img/qnk.png" type="image/png">
</head>

<body>

  <header class="header">
    <div class="logo"><a href="./inicio.php" style="color: white; text-decoration: none;">QNK Music</a></div>
    <nav class="navbar">
      <ul>
        <li><a href="./form_perfil.php">Perfil</a></li>
        <li><a href="./playlist.php">Playlist</a></li>
        <li><a href="./favoritos.php">Canciones Fav.</a></li>
        <li><a href="./artistas_favoritos.php">Artistas Fav</a></li>
        <li><a href="./logout.php">Cerrar Sesión</a></li>
      </ul>
      

    </nav>
  </header>

  <main>
    <div class="search-container">
      <input type="text" id="search-input" class="search-bar" placeholder="Buscar artista, álbum o canción...">
    </div>

    <div id="search-results" class="results-container">
      <!-- Resultados dinámicos -->
    </div>

    <div id="sentinel"></div> <!-- Para IntersectionObserver -->
  </main>

  <!-- Player Spotify (solo iframe) -->
  <div id="player-container">
    <!-- Aquí se cargará dinámicamente el iframe de Spotify -->
  </div>

</body>

</html>
