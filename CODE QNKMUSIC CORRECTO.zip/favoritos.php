<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

if (!isset($_SESSION['id_usuario'])) {
    header("Location: index.php");
    exit;
}

$idUsuario = $_SESSION['id_usuario'];

$conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$sql = "SELECT c.IdCancion, c.Titulo, c.Portada, c.URL, a.NombreArtista 
        FROM Favoritos_Canciones fc
        JOIN Canciones c ON fc.IdCancion = c.IdCancion
        LEFT JOIN Artistas a ON c.IdArtista = a.IdArtista
        WHERE fc.IdUsuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$resultado = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Favoritos - QNK Music</title>
    <link rel="stylesheet" href="css/favoritos.css">
        <script src="js/favoritos.js" defer></script>
        <link rel="icon" href="img/qnk.png" type="image/png">
 
</head>
<body>

<header class="header">
    <div class="logo"><a href="./inicio.php">QNK Music</a></div>
    <nav class="navbar">
        <ul>
            <li><a href="./buscar.php">Buscar</a></li>
            <li><a href="./playlist.php">Playlist</a></li>
            <li><a href="./artistas_favoritos.php">Artistas Fav.</a></li>
            <li><a href="./form_perfil.php">Perfil</a></li>
            <li><a href="./logout.php">Cerrar Sesión</a></li>
        </ul>
    </nav>
</header>

<main class="main-content">
    <h2>Tus Canciones Favoritas</h2>

    <?php if ($resultado->num_rows > 0): ?>
        <div class="results-container">
            <?php while ($row = $resultado->fetch_assoc()): ?>
                <div class="result-item" onclick="reproducir('<?php echo htmlspecialchars($row['URL']); ?>')">
                    <img src="<?php echo htmlspecialchars($row['Portada'] ?? 'img/default_cover.png'); ?>" alt="cover" class="album-cover">
                    <div class="result-details">
                        <strong><?php echo htmlspecialchars($row['Titulo']); ?></strong>
                        <span><?php echo htmlspecialchars($row['NombreArtista'] ?? 'Artista desconocido'); ?></span>
                    </div>
                    <form method="POST" action="eliminar_favorito.php" class="form-eliminar" onsubmit="event.stopPropagation(); return confirm('¿Eliminar de favoritos?');">
                        <input type="hidden" name="id_cancion" value="<?php echo $row['IdCancion']; ?>">
                        <button type="submit" class="btn-eliminar-cancion">🗑️</button>
                    </form>
                </div>
            <?php endwhile; ?>
        </div>
        <div id="player-container" class="player-container" style="display: none;"></div>
    <?php else: ?>
        <p class="no-songs">Todavía no tienes canciones favoritas.</p>
    <?php endif; ?>
</main>

</body>
</html>
