<?php
session_start();
// Prevenir cacheo para que el botón atrás no vuelva a mostrar la página tras logout
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include "include/CredencialesBD.php";

if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    echo "❌ No hay sesión iniciada.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $idUsuario = $_SESSION['id_usuario'];
    $titulo = $_POST['titulo'] ?? '';
    $artista = $_POST['artista'] ?? '';
    $portada = $_POST['portada'] ?? '';
    $previewUrl = $_POST['preview_url'] ?? '';

    if ($titulo && $artista && $previewUrl) {
        $conn = new mysqli($dbhost, $usuario, $password, "u968449334_reproductor");
        if ($conn->connect_error) {
            die("❌ Error de conexión: " . $conn->connect_error);
        }

        echo "✅ Conexión establecida<br>";

        // 1. HistorialUltimaReproduccion
        $query = "INSERT INTO HistorialUltimaReproduccion (IdUsuario, UltimoTitulo, UltimoArtista, UltimaPortada, UltimaURL) 
                  VALUES (?, ?, ?, ?, ?)
                  ON DUPLICATE KEY UPDATE 
                    UltimoTitulo = VALUES(UltimoTitulo),
                    UltimoArtista = VALUES(UltimoArtista),
                    UltimaPortada = VALUES(UltimaPortada),
                    UltimaURL = VALUES(UltimaURL)";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            die("❌ Error al preparar historial última: " . $conn->error);
        }
        $stmt->bind_param("issss", $idUsuario, $titulo, $artista, $portada, $previewUrl);
        $stmt->execute();
        echo "✅ Última reproducción actualizada<br>";
        $stmt->close();

        // 2. Verificar artista
        $stmt = $conn->prepare("SELECT IdArtista FROM Artistas WHERE NombreArtista = ?");
        if (!$stmt) {
            die("❌ Error al preparar artista: " . $conn->error);
        }
        $stmt->bind_param("s", $artista);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $idArtista = $row['IdArtista'];
            echo "🎤 Artista encontrado: ID $idArtista<br>";
        } else {
            $stmtInsert = $conn->prepare("INSERT INTO Artistas (NombreArtista, ImagenArtista) VALUES (?, '')");
            $stmtInsert->bind_param("s", $artista);
            $stmtInsert->execute();
            $idArtista = $stmtInsert->insert_id;
            echo "🎤 Artista insertado: ID $idArtista<br>";
            $stmtInsert->close();
        }
        $stmt->close();

        // 3. Verificar canción
        $stmt = $conn->prepare("SELECT IdCancion FROM Canciones WHERE Titulo = ? AND IdArtista = ?");
        if (!$stmt) {
            die("❌ Error al preparar canción: " . $conn->error);
        }
        $stmt->bind_param("si", $titulo, $idArtista);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            $idCancion = $row['IdCancion'];
            echo "🎵 Canción encontrada: ID $idCancion<br>";
        } else {
            $stmtInsert = $conn->prepare("INSERT INTO Canciones (Titulo, NombreAlbum, Portada, URL, IdArtista) VALUES (?, '', ?, ?, ?)");
            $stmtInsert->bind_param("sssi", $titulo, $portada, $previewUrl, $idArtista);
            $stmtInsert->execute();
            $idCancion = $stmtInsert->insert_id;
            echo "🎵 Canción insertada: ID $idCancion<br>";
            $stmtInsert->close();
        }
        $stmt->close();

        // 4. Insertar historial reproducción
        $stmt = $conn->prepare("INSERT INTO Historial_Reproduccion (IdUsuario, IdCancion) VALUES (?, ?)");
        if (!$stmt) {
            die("❌ Error al preparar historial_reproduccion: " . $conn->error);
        }
        $stmt->bind_param("ii", $idUsuario, $idCancion);
        if ($stmt->execute()) {
            echo "✅ Historial de reproducción guardado correctamente.";
        } else {
            echo "❌ Fallo insertando en Historial_Reproduccion: " . $stmt->error;
        }
        $stmt->close();

        $conn->close();
    } else {
        http_response_code(400);
        echo "❌ Faltan datos obligatorios.";
    }
} else {
    http_response_code(405);
    echo "❌ Método no permitido.";
}
